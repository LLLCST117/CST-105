//This program prompts user to enter a number between
//1 and 10000. It utilizes a while loop.
//Program by Linda Lee
//Created on 01/30/18

import java.util.Random;
import java.util.Scanner;

public class GuessGameEx {

	public static void main(String[] args) {
		Random random = new Random();
		Scanner scan = new Scanner(System.in);
		
		int ranNum, numGuess = 0,count = 0;
		
		ranNum = random.nextInt(10000)+1;
		
		while (numGuess !=ranNum) {
			System.out.print("Enter a guess between 1 and 10000: ");
			numGuess = scan.nextInt();
			
			if (numGuess > ranNum)
				System.out.println("LOWER");
				
			else if (numGuess < ranNum)
				System.out.println("HIGHER");
			count++;
		}
		
		System.out.println("You WIN. It took you " + count+" guesses.");	
	}
}


