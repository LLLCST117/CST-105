//This program reads a text file within project called Piglatin it 
//outputs the first column with original file and the piglatin word in the next
//column as a tabular format.
//Program by Linda Lee, 01/30/18
//CST-105

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
public class PiglatinEx
{
    public static void main(String args[]) throws FileNotFoundException
    {
    	//Creates File to refer to file in project
        File file = new File("input.txt");
      
        //Creates the Scanner to read File 
        Scanner scan = new Scanner(file);
                               
       while (scan.hasNext()){
       
       String word= scan.next();
       String piglatin="";
       //Check for vowel
       int checkv=0;
       for(int i=0;i<word.length();i++){
        
        char x=word.charAt(i);
            if(x=='A' || x=='E' || x=='I' || x=='O' ||x=='U'||x=='a' || x=='e' || x=='i' || x=='o' ||x=='u'){
                piglatin=word.substring(i)+word.substring(0,i)+"WAY";
                checkv=1;
            }          
        }
     if (checkv==0){    
          piglatin=word+"AY";
        } 
     //Prints out original word with piglatin by using the print format
        System.out.printf(word+"%15s\n",piglatin.toUpperCase());
    }
  }
 }

    
        

