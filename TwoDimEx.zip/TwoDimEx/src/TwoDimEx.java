//This program reads text file and creates a two dimensional
//char array. It fills array by rows.
//Program created by Linda Lee
//Created on 02/04/18
//Exercise 5 for CST-105
// Instructor: Mohamed Mneimneh


import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class TwoDimEx{
	
	public static void main(String[] args) throws FileNotFoundException {
		//Read text file	
		String theString = "";
		File file = new File("input2.txt");
		Scanner scan = new Scanner(file);
		theString = scan.nextLine();
		while (scan.hasNextLine()) {
		       theString = theString + "\n" + scan.nextLine();
		}
		//String to characters
		char[]allChars = new char[theString.length()];
		for (int i = 0; i < theString.length(); i++) {
			allChars[i] = theString.charAt(i);
			System.out.println(allChars[i]);	
		}
		
		 int i,j,k=0;
	        char twoDim[][] = new char[20][45];
	        for(i=0;i<20;i++){
	            for(j=0;j<45;j++){
	                    twoDim[i][j] = allChars[k];
	                    k++;
	            }
	        }
	        for(i=0;i<20;i++){
	            for(j=0;j<45;j++){
	               System.out.print(twoDim[i][j]);
	            }
	            System.out.println("");
	        }
	        System.out.println();
	        for(j=0;j<45;j++){
	            for(i=0;i<20;i++){
	               System.out.print(twoDim[i][j]);
	            }
	            System.out.print("");      
	        	}
	        System.out.println();
	        System.out.println();
	}
}
  

		
		
		
		
		
		
		

	


