// CST-105
//Linda Lee, 02/11/18
//Milestone2
//Creation of the NFL Player class

import java.util.Scanner;

public class NflPlayerTest {

	public static void main(String[] args) {
		String Fname,Lname,Position,College; 
		int Age = 0;
		int Height = 0; 
		int Weight = 0;
		int TDowns = 0;
		int Rushes = 0;
		int Interceptions = 0;
		Scanner scan = new Scanner(System.in);	
	
	NflPlayer nflplayer = new NflPlayer(null, null, null, null, 0, 0, 0, 0, 0, 0, 0, 0);
	
	System.out.println("Please enter Player's first name, lastname, position, "
			+ "college, age, height in inches, weight in lbs, number of TD, number of rushes, and number of interceptions.");
	
	Fname = scan.next();
	Lname = scan.next();
	Position = scan.next();
	College = scan.next();
	Age = scan.nextInt();
	Height = scan.nextInt();
	Weight = scan.nextInt();
	TDowns = scan.nextInt();
	Rushes = scan.nextInt();
	Interceptions = scan.nextInt();
	
	
	nflplayer.setFName(Fname);
	nflplayer.setLName(Lname);
	nflplayer.setPPosition(Position);
	nflplayer.setPCollege(College);
	nflplayer.setPAge(Age);
	nflplayer.setPHeight(Height);
	nflplayer.setPWeight(Weight);
	nflplayer.setPTDowns(TDowns);
	nflplayer.setPRushes(Rushes);
	nflplayer.setPInterceptions(Interceptions);
	
	System.out.print("Here is your data for your NFl player: \n" );
	
	System.out.println("\n"+ nflplayer);	
	}	
}
