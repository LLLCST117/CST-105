// CST-105
//Linda Lee, 02/11/18
//Milestone3
//Creation of the NFL Player Manager

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class NflPlayerManager {
	public static void main(String[] args) throws FileNotFoundException { 
		Scanner scan = new Scanner(new File("MyRoster.txt"));
	
	ArrayList<String> nflAlist = new ArrayList<String>();
	
	while (scan.hasNextLine())
		nflAlist.add(scan.nextLine());
	
	System.out.println(nflAlist);
	
 }
}
