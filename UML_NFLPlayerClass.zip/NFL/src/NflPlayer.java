
public class NflPlayer {
	
	//private fields
	private String fname,lname,position,college;	
	private int age,height,weight,tdowns,rushes,interceptions,totalRate, avgRate;
	
	//constructors
	public NflPlayer(String Fname,String Lname,String Position,String College, 
			int Age,int Height,int Weight,int TDowns,int Rushes,int Interceptions,int Totalrate,int Avgrate) {
		
		fname = Fname;
		lname = Lname;
		position = Position;
		college = College;
		age = Age;
		//height in inches
		height = Height;
		//weight in pounds (lbs)
		weight = Weight;
		tdowns = TDowns;
		rushes = Rushes;
		interceptions = Interceptions;
		//totalRate = Totalrate;
		//avgRate = Avgrate;
		}
			
	//getters for all properties
	public String getFName() {
		return fname;
	}
	public String getLName() {
		return lname;
	}
	public String getPPosition() {
		return position;
	}
	public String getPCollege() {
		return college;
	}
	public int getPAge() {
		return age;
	}
	public int getPHeight() {
		return height;
	}
	public int getPWeight() {
		return weight;
	}
	public int getPTDowns() {
		return tdowns;
	}
	public int getPRushes() {
		return rushes;
	}
	public int getPInterceptions() {
		return interceptions;
	}
	
	
	//Setters for all properties
	public void setFName(String Fname) {
		fname = Fname;
	}
	public void setLName(String Lname) {
		lname = Lname;
	}
	public void setPPosition(String Position) {
		position = Position;
	}
	public void setPCollege(String College) {
		college = College;
	}
	public void setPAge(int Age) {
		age = Age;
	}
	public void setPHeight(int Height) {
		height = Height;
	}
	public void setPWeight(int Weight) {
		weight = Weight;
	}
	public void setPTDowns(int TDowns) {
		tdowns = TDowns;
	}
	public void setPRushes(int Rushes) {
		rushes = Rushes;
	}
	public void setPInterceptions(int Interceptions) {
		interceptions = Interceptions;
	}
	
	
	//String to display the user input of the Player information
	public String toString() {
		return fname +"   "+lname+"   "+position+"   "+college+"   "+age+"   "+height+"   "+weight+"   "+tdowns+"   "+rushes+"   "+interceptions;
	}
	
}
